from setuptools import setup

setup(
    name='paquete',
    version='1.0',
    description='Paquete para modelar clientes y productos en una página de compras',
    author='Justo Ghioldi',
    author_email='justoghioldi23@gmail.com',

    packages=["paquete"],
)
